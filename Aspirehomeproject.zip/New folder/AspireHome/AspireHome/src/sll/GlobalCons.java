package sll;

public class GlobalCons {
   public static String AUTH = "auth";
}
