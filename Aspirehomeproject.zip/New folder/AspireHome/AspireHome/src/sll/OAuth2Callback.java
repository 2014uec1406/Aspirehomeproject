package sll;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * Servlet implementation class OAuth2Callback
 */
public class OAuth2Callback extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public OAuth2Callback() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			// get code
			String code = request.getParameter("code");
			// format parameters to post
			String urlParameters = "code=" + code
					+ "&client_id=995231160151-ilcpeeq8qjmp5sq094u9ek96nibaquef.apps.googleusercontent.com"
					+ "&client_secret=9kGqNsbKeI_lyzwFHn7P447_"
					+ "&redirect_uri=http://localhost:8080/AspireHome/OAuth2Callback" + "&grant_type=authorization_code";

			// post parameters
			System.out.println("hello");
			URL url = new URL("https://accounts.google.com/o/oauth2/token");
			URLConnection urlConn = url.openConnection();
			urlConn.setDoOutput(true);
			OutputStreamWriter writer = new OutputStreamWriter(urlConn.getOutputStream());
			writer.write(urlParameters);
			writer.flush();

			// get output in outputString
			String line, outputString = "";
			BufferedReader reader = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));
			while ((line = reader.readLine()) != null) {
				outputString += line;
			}
			System.out.println("sumit1"+outputString);

			// get Access Token
			//@SuppressWarnings("restriction")
			JsonObject json = (JsonObject) new JsonParser().parse(outputString);
			//@SuppressWarnings("restriction")
			String access_token = json.get("access_token").getAsString();
			 System.out.println("sumit2"+access_token);

			// get User Info
			url = new URL("https://www.googleapis.com/oauth2/v1/userinfo?access_token=" + access_token);
			urlConn = url.openConnection();
			outputString = "";
			reader = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));
			while ((line = reader.readLine()) != null) {
				outputString += line;
			}
			 System.out.println("sumit3"+outputString);

			// Convert JSON response into Pojo class
			//@SuppressWarnings("restriction")
			GooglePojo data = new Gson().fromJson(outputString, GooglePojo.class);
			System.out.println(data);
			writer.close();
			reader.close();
			request.setAttribute("auth", data);
		
			request.getRequestDispatcher("/temp.jsp").forward(request, response);
			//request.sendRedirect("/google.jsp");
			
		} catch (MalformedURLException e) {
			System.out.println(e);
		} catch (ProtocolException e) {
			System.out.println(e);
		} catch (IOException e) {
			System.out.println(e);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
