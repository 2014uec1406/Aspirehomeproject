package sll;
import java.sql.*;
public class database {
	

	public static void main(String[] args) {
		
	
		// TODO Auto-generated constructor stub
		try{
			Connection myconn = DriverManager.getConnection("jdbc:mysql://localhost:3306/demo", "root", "jaysumit96");
			Statement mystmt = myconn.createStatement();
			
			 
			ResultSet myrs = mystmt.executeQuery("select * from logininfo");
			
			while(myrs.next()){
				System.out.println(myrs.getString("id"));
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	
}
